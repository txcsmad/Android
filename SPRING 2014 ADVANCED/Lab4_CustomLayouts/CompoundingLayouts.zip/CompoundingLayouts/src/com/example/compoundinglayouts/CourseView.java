//declare package name
package com.example.compoundinglayouts;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.RelativeLayout;
import android.widget.TextView;

//create the class
public class CourseView extends RelativeLayout {
	
	public CourseView(Context context, AttributeSet attrs) {
		super(context, attrs);
		
		//grab the xml or custom fields
		TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.CourseView, 0, 0);
		String courseN = a.getString(R.styleable.CourseView_courseName);
		String assignmentN = a.getString(R.styleable.CourseView_assignmentName);
		
		//set the textviews aka Class and Assignment
		
		LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		inflater.inflate(R.layout.course_view, this, true);
		
		TextView courseName = (TextView) findViewById(R.id.courseName);
		String className = courseName.getText().toString();
		courseName.setText(className + " " + courseN);
		
		TextView assignment = (TextView) findViewById(R.id.assignmentName);
		assignment.setText(assignmentN);
		
	}
}