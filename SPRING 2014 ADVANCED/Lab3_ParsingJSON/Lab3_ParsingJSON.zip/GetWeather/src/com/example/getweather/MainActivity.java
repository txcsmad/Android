package com.example.getweather;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import org.json.JSONObject;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.widget.TextView;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		GetWeatherTask weather = new GetWeatherTask();
		weather.execute(new String[] {"http://query.yahooapis.com/v1/public/yql?q=select%20item%20from%20weather.forecast%20where%20location%3D%2248907%22&format=json"});
		
		weather.execute(new String[] {"enter url here"} );
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	
	
	private class GetWeatherTask extends AsyncTask<String, Void, String>  {

		private InputStream getHttpConnection(String urlString) throws Exception {
			InputStream in_s = null;
			URL url = new URL(urlString);
			URLConnection urlConnection = url.openConnection();
			
			try {
				HttpURLConnection httpURLConnection = (HttpURLConnection) urlConnection;
				httpURLConnection.setRequestMethod("GET");
				httpURLConnection.connect();
				
				if (httpURLConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
					in_s = httpURLConnection.getInputStream();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			return in_s;
		}
		
		private JSONObject getJSON(String urlString) throws Exception {
			InputStream inputStream = getHttpConnection(urlString);
			BufferedReader br = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"), 8);
			StringBuilder json = new StringBuilder();
			String line;
			JSONObject jsonObject = new JSONObject();
			
			if (inputStream != null) {
				while ((line = br.readLine()) != null) {
					json.append(line + "\n");
				}
				inputStream.close();
			}
			
			try {
				jsonObject = new JSONObject(json.toString());
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			return jsonObject;
		}
		
		@Override
		protected String doInBackground(String... arg0) {
			// TODO Auto-generated method stub
			
			//parse information
			JSONObject weatherObject = null;
			String result = "";
			try {
				weatherObject = getJSON(arg0[0]);
				JSONObject query = weatherObject.getJSONObject("query");
				JSONObject results = query.getJSONObject("results");
				JSONObject channel = results.getJSONObject("channel");
				JSONObject item = channel.getJSONObject("item");
				result = item.getString("title");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return result;
		}
		
		@Override
		protected void onPostExecute(String result) {
			TextView downloadedData = (TextView) findViewById(R.id.downloadedData);
			downloadedData.setText(result);
		}
		
	}

}
