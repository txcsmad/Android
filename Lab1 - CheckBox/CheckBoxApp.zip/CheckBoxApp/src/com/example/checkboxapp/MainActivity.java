package com.example.checkboxapp;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;

public class MainActivity extends Activity {

	CheckBox boldBox;
	CheckBox italicsBox;
	TextView textView;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		boldBox = (CheckBox) findViewById(R.id.boldBox);
		italicsBox = (CheckBox) findViewById(R.id.italicsBox);
		textView = (TextView) findViewById(R.id.textView1);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	public void onCheckBoxClicked(View view) {
		//Is the checkBox clicked?
		boolean isBoldBoxChecked = boldBox.isChecked();
		boolean isItalicsBoxChecked = italicsBox.isChecked();
		
		if (isBoldBoxChecked && isItalicsBoxChecked) {
			textView.setTypeface(null, Typeface.BOLD_ITALIC);
		}
		else if (isBoldBoxChecked && !isItalicsBoxChecked) {
			textView.setTypeface(null, Typeface.BOLD);
		}
		else if (!isBoldBoxChecked && isItalicsBoxChecked) {
			textView.setTypeface(null, Typeface.ITALIC);
		}
		else {
			textView.setTypeface(null, Typeface.NORMAL);
		}
	}

}
