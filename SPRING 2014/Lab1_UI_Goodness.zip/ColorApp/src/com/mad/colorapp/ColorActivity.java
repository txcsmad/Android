package com.mad.colorapp;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ColorActivity extends Activity {
	
	TextView title;
	LinearLayout layout;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_color);
		
		title = (TextView) findViewById(R.id.title);
		layout = (LinearLayout) findViewById(R.id.layout);
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.color, menu);
		return true;
	}
	
	public void setColor(View v){
		switch(v.getId()){
			case(R.id.yellow):
				title.setTextColor(Color.YELLOW);
				break;
			case(R.id.cyan):
				title.setTextColor(Color.CYAN);
				break;
			case(R.id.blue):
				title.setTextColor(Color.BLUE);
				break;
			case(R.id.yellow_layout):
				layout.setBackgroundColor(Color.YELLOW);
				break;
			case(R.id.cyan_layout):
				layout.setBackgroundColor(Color.CYAN);
				break;
			case(R.id.blue_layout):
				layout.setBackgroundColor(Color.BLUE);
				break;
		}
		
	}
}
