/** Automatically generated file. DO NOT MODIFY */
package com.mad.colorapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}