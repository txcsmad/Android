package com.mad.calculater;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class CalculaterActivity extends ActionBarActivity {

	private TextView textview;
	private Button zero;
	private Button one;
	private Button two;
	private Button three;
	private Button four;
	private Button five;
	private Button six;
	private Button seven;
	private Button eight;
	private Button nine;
	private Button equals;
	private Button plus;
	private Button subtract;
	private Button multiply;
	private Button divide;
	private int first_number;
	private int second_number;
	private enum Operation {PLUS, SUBTRACT, MULTIPLY, DIVIDE}
	private Operation opr;
	
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_calculater);
		
		textview = (TextView) findViewById(R.id.textview);
		zero = (Button) findViewById(R.id.zero);
		one = (Button) findViewById(R.id.one);
		two = (Button) findViewById(R.id.two);
		three = (Button) findViewById(R.id.three);
		four = (Button) findViewById(R.id.four);
		five = (Button) findViewById(R.id.five);
		six = (Button) findViewById(R.id.six);
		seven = (Button) findViewById(R.id.seven);
		eight = (Button) findViewById(R.id.eight);
		nine = (Button) findViewById(R.id.nine);
		equals = (Button) findViewById(R.id.equals);
		plus = (Button) findViewById(R.id.plus);
		subtract = (Button) findViewById(R.id.subtract);
		multiply = (Button) findViewById(R.id.multiply);
		divide = (Button) findViewById(R.id.divide);
		
		zero.setOnClickListener(viewListener);
		one.setOnClickListener(viewListener);
		two.setOnClickListener(viewListener);
		three.setOnClickListener(viewListener);
		four.setOnClickListener(viewListener);
		five.setOnClickListener(viewListener);
		six.setOnClickListener(viewListener);
		seven.setOnClickListener(viewListener);
		eight.setOnClickListener(viewListener);
		nine.setOnClickListener(viewListener);
		equals.setOnClickListener(viewListener);
		plus.setOnClickListener(viewListener);
		subtract.setOnClickListener(viewListener);
		multiply.setOnClickListener(viewListener);
		divide.setOnClickListener(viewListener);
		

		
	}
	
	View.OnClickListener viewListener = new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			switch(v.getId()){
				case R.id.plus:
					first_number = Integer.parseInt(textview.getText().toString());
					textview.setText("0");
					opr = Operation.PLUS;
					break;
				case R.id.subtract:
					first_number = Integer.parseInt(textview.getText().toString());
					textview.setText("0");
					opr = Operation.SUBTRACT;
					break;
				case R.id.divide:
					first_number = Integer.parseInt(textview.getText().toString());
					textview.setText("0");
					opr = Operation.DIVIDE;
					break;
				case R.id.multiply:
					first_number = Integer.parseInt(textview.getText().toString());
					textview.setText("0");
					opr = Operation.MULTIPLY;
					break;
					
					
				case R.id.equals:
					second_number = Integer.parseInt(textview.getText().toString());
					int result = 0;
					if (opr == Operation.PLUS){
						result = first_number + second_number;
					}else if(opr == Operation.SUBTRACT){
						result = first_number - second_number;
					}else if (opr == Operation.MULTIPLY){
						result = first_number * second_number;
					}else if (opr == Operation.DIVIDE){
						result = first_number / second_number;
					}
					textview.setText("" + result);
					break;
				
				default:
					String str = textview.getText().toString();
					if (str.equals("0")){
						str = ((Button)v).getText().toString();
					} else{
						str = str + ((Button)v).getText().toString();
					}
					textview.setText(str);
					break;
			}
			
		}
	};

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.calculater, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	

}
