package com.mad.tapcounter;


import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.parse.ParseObject;

public class GameActivity extends Activity {
	
	private Timer myTimer;
	private long mStartTime;
	private TextView timer;
	private TextView score_text;
	private Button clicker;
	private EditText input_name;
	private Button submit_name;
	private int score_num;
	private int total_time = 10;
	private int time_left;
	
	private SoundPool mSounds;
	private int mCoinSound;
	private Dialog dlog;
	private int current_high_score;
	
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_game);
		
		
		Typeface face = Typeface.createFromAsset(getAssets(),"fonts/Roboto/Roboto-Light.ttf");
		timer = (TextView) findViewById(R.id.timer);
		score_text = (TextView) findViewById(R.id.score);
		
		score_text.setTypeface(face);
		score_text.setOnClickListener(clickerListener);
		
		mStartTime = System.currentTimeMillis();
        
        myTimer = new Timer();
		myTimer.schedule(new TimerTask() {			
			@Override
			public void run() {
				TimerMethod();
			}
			
		}, 0, 1000);
		
	}
	
	@Override
	protected void onResume() {		
		super.onResume();
		mSounds = new SoundPool(2, AudioManager.STREAM_MUSIC, 0);
		// 2 = maximum sounds ot play at the same time, 
		// AudioManager.STREAM_MUSIC is the stream type typically used for games
		// 0 is the "the sample-rate converter quality. Currently has no effect. Use 0 for the default."
		
		mCoinSound = mSounds.load(this, R.raw.smw_coin, 1); 
		// Context, id of resource, priority (currently no effect)
	}
	
	@Override
	protected void onPause() {
		super.onPause();
				
		if(mSounds != null) {
			mSounds.release();
			mSounds = null;
		}		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.game, menu);
		return true;
	}

	
	
	View.OnClickListener clickerListener = new View.OnClickListener() {
		  public void onClick(View v) {
			  switch (v.getId()){
			  	case R.id.score:
			  		score_num = score_num + 1;
			  		if (score_num >= 100){
						score_text.setTextSize(TypedValue.COMPLEX_UNIT_DIP,140);
					}
			  		score_text.setText("" + score_num);
					// soundID, leftVolume, rightVolume, priority, loop, rate
					mSounds.play(mCoinSound, 1, 1, 1, 0, 1);
					
			  		break;
			  	case R.id.name_submit:
			  		String user = input_name.getText().toString();
			  		
			  		if( !(user.equals(""))){
			  			saveHighScoreToParse(user,score_num);
			  			finishActivity(user);
			  		}
			  		break;
			  }
		  }
	};
	
	private void TimerMethod()
	{
		//This method is called directly by the timer
		//and runs in the same thread as the timer.
		long millis = System.currentTimeMillis() - mStartTime;
		int seconds = (int) (millis / 1000);
		
		time_left = total_time - seconds;
	   
		//We call the method that will work with the UI
		//through the runOnUiThread method.
		this.runOnUiThread(Timer_Tick);
	    
	}
	
	private Runnable Timer_Tick = new Runnable() {
		public void run() {
		
		//This method runs in the same thread as the UI.    	       
		//Do something to the UI thread here
			if (time_left < 0){
				if (score_num > current_high_score){
					showDialog();
				}
				else{
					finishActivity();
				}
				myTimer.cancel();
			}
			else{
				timer.setText("Timer: " + time_left);
			}
		}
	};
	
	private void showDialog(){
		dlog = new android.app.Dialog(GameActivity.this, android.R.style.Theme_Holo_Light_Dialog_NoActionBar_MinWidth);
        dlog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dlog.setContentView(R.layout.dialog_highscore);
        
        input_name = (EditText) dlog.findViewById(R.id.name_input);
        submit_name = (Button) dlog.findViewById(R.id.name_submit);
        submit_name.setOnClickListener(clickerListener);
        dlog.show();
	}
	
	private void finishActivity(String user){
		Intent i = getIntent();
		i.putExtra("high_score", score_num);
		i.putExtra("username", user);
		setResult(RESULT_OK, i);
		finish();
		overridePendingTransition(0,R.anim.bottom_up);
	}
	
	private void finishActivity(){
		Intent i = getIntent();
		setResult(RESULT_OK, i);
		finish();
		overridePendingTransition(0,R.anim.bottom_up);
	}

	public void saveHighScoreToParse(String username, int newScore) {
        ParseObject newHighScore = new ParseObject("Highscore");
        newHighScore.put("username", username);
        newHighScore.put("score", newScore);
        newHighScore.saveInBackground();
    }
}
