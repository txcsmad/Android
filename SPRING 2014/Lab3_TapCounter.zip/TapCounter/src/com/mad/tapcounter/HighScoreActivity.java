package com.mad.tapcounter;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;

public class HighScoreActivity extends Activity {
	
	private ListView listView;
	private CustomHighScoreListAdapter adapter;
	private ArrayList<Score> highScoreList;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_high_score);

		listView = (ListView) findViewById(R.id.highscore_listview);
		setupListView();
		
		ParseQuery<ParseObject> query = ParseQuery.getQuery("Highscore");
        query.orderByDescending("score");
        query.setLimit(20);
        
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> parseObjects, ParseException e) {
                if (e == null) {        // Successful
                    for (ParseObject parseScoreObj : parseObjects) {
                        Score newScore = new Score(parseScoreObj.getString("username"),
                                   parseScoreObj.getInt("score"));
                        highScoreList.add(newScore);
                    }
                    
                    adapter.notifyDataSetChanged();
                }  
                else {
                	Log.e("ERRRORRRRRRR", "Parse Expection! " + e);
                }
            }
        });
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.high_score, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	private void setupListView(){
        highScoreList = new ArrayList<Score>();
        
        adapter = new CustomHighScoreListAdapter(HighScoreActivity.this,
                R.layout.highscore_item,highScoreList);
 	    listView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }



}
