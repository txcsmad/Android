package com.nlaz.tapcounter;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

class CustomHighScoreListAdapter extends ArrayAdapter<Score> {
    Context mContext;
    int textViewResourceId;
    ArrayList<Score> data;

    public CustomHighScoreListAdapter(Context context, int textViewResourceId, ArrayList<Score> objects) {
        super(context, textViewResourceId, objects);
        this.mContext = context;
        this.textViewResourceId = textViewResourceId;
        this.data = objects;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) mContext.getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(textViewResourceId, parent, false);
        }

        Score scoreObj = data.get(position);

        TextView usernameTextView = (TextView) convertView.findViewById(R.id.highscore_name);
        usernameTextView.setText(scoreObj.getUsername());

        TextView scoreTextView = (TextView) convertView.findViewById(R.id.highscore_score);
        scoreTextView.setText(scoreObj.getScoreString());

        return convertView;
    }

}

