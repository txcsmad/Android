package com.nlaz.tapcounter;


import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class GameActivity extends Activity {
	
	private Timer myTimer;
	private long mStartTime;
	private TextView timer;
	private TextView score_text;
	private Button clicker;
	private int score_num;
	private int total_time = 10;
	private int time_left;
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_game);
		
		timer = (TextView) findViewById(R.id.timer);
		score_text = (TextView) findViewById(R.id.score);
		clicker = (Button) findViewById(R.id.clicker);
		
		clicker.setOnClickListener(clickerListener);
		
		mStartTime = System.currentTimeMillis();
        
        myTimer = new Timer();
		myTimer.schedule(new TimerTask() {			
			@Override
			public void run() {
				TimerMethod();
			}
			
		}, 0, 1000);
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.game, menu);
		return true;
	}
	
	View.OnClickListener clickerListener = new View.OnClickListener() {
		  public void onClick(View v) {
			  score_num = score_num + 1;
			  score_text.setText("" + score_num);
		  }
	};
	
	private void TimerMethod()
	{
		//This method is called directly by the timer
		//and runs in the same thread as the timer.
		long millis = System.currentTimeMillis() - mStartTime;
		int seconds = (int) (millis / 1000);
		
		time_left = total_time - seconds;
	      
	    if (time_left < 0){
	    	 finishActivity();
	    }
	    else{
			//We call the method that will work with the UI
			//through the runOnUiThread method.
			this.runOnUiThread(Timer_Tick);
	    }
	}
	
	private Runnable Timer_Tick = new Runnable() {
		public void run() {
		
		//This method runs in the same thread as the UI.    	       
		//Do something to the UI thread here
		timer.setText("Timer: " + time_left);
	
		}
	};
	
	private void finishActivity(){
		Intent i = getIntent();
		i.putExtra("score", score_num);
		setResult(RESULT_OK, i);
		myTimer.cancel();
		finish();
	}

}
