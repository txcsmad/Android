package com.nlaz.tapcounter;


import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class GameActivity extends Activity {
	
	private Timer myTimer;
	private long mStartTime;
	private TextView timer;
	private TextView score_text;
	private Button clicker;
	private int score_num;
	private int total_time = 10;
	private int time_left;
	
	private SoundPool mSounds;
	private int mCoinSound;
	
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_game);
		
		
		Typeface face = Typeface.createFromAsset(getAssets(),"fonts/Roboto/Roboto-Light.ttf");
		timer = (TextView) findViewById(R.id.timer);
		score_text = (TextView) findViewById(R.id.score);
		clicker = (Button) findViewById(R.id.clicker);
		
		score_text.setTypeface(face);
		score_text.setOnClickListener(clickerListener);
		
		mStartTime = System.currentTimeMillis();
        
        myTimer = new Timer();
		myTimer.schedule(new TimerTask() {			
			@Override
			public void run() {
				TimerMethod();
			}
			
		}, 0, 1000);
		
	}
	
	@Override
	protected void onResume() {		
		super.onResume();
		mSounds = new SoundPool(2, AudioManager.STREAM_MUSIC, 0);
		// 2 = maximum sounds ot play at the same time, 
		// AudioManager.STREAM_MUSIC is the stream type typically used for games
		// 0 is the "the sample-rate converter quality. Currently has no effect. Use 0 for the default."
		
		mCoinSound = mSounds.load(this, R.raw.smw_coin, 1); 
		// Context, id of resource, priority (currently no effect)
	}
	
	@Override
	protected void onPause() {
		super.onPause();
				
		if(mSounds != null) {
			mSounds.release();
			mSounds = null;
		}		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.game, menu);
		return true;
	}

	
	
	View.OnClickListener clickerListener = new View.OnClickListener() {
		  public void onClick(View v) {
			  score_num = score_num + 1;
			  score_text.setText("" + score_num);
			  mSounds.play(mCoinSound, 1, 1, 1, 0,1);
		  }
	};
	
	private void TimerMethod()
	{
		//This method is called directly by the timer
		//and runs in the same thread as the timer.
		long millis = System.currentTimeMillis() - mStartTime;
		int seconds = (int) (millis / 1000);
		
		time_left = total_time - seconds;
	   
		//We call the method that will work with the UI
		//through the runOnUiThread method.
		this.runOnUiThread(Timer_Tick);
	    
	}
	
	private Runnable Timer_Tick = new Runnable() {
		public void run() {
		
		//This method runs in the same thread as the UI.    	       
		//Do something to the UI thread here
			if (time_left < 0){
				finishActivity();
			}
			else{
				timer.setText("Timer: " + time_left);
			}
		}
	};
	
	private void finishActivity(){
		Intent i = getIntent();
		i.putExtra("score", score_num);
		setResult(RESULT_OK, i);
		myTimer.cancel();
		finish();
		overridePendingTransition(0,R.anim.bottom_up);
	}

}
