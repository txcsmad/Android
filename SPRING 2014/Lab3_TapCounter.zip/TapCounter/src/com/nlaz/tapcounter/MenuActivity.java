package com.nlaz.tapcounter;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MenuActivity extends Activity {

	private TextView highscore;
	private Button new_game;
	private Button instructions;
	private int max_score;
	
	public int LOGIN_REQUEST_ID = 1234;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_menu);
		
		highscore = (TextView) findViewById(R.id.highscore);
		new_game = (Button) findViewById(R.id.new_game);
		instructions = (Button) findViewById(R.id.instructions);
		
		new_game.setOnClickListener(newGameListener);
		instructions.setOnClickListener(instructionsListener);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.menu, menu);
		return true;
	}
	
	View.OnClickListener newGameListener = new View.OnClickListener() {
		  public void onClick(View v) {
			  
			  Intent startIntent = new Intent(MenuActivity.this, GameActivity.class);
			  startIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
			  startActivityForResult(startIntent,LOGIN_REQUEST_ID);
			  overridePendingTransition(R.anim.top_down, 0);
		      
		  }
	};
	
	View.OnClickListener instructionsListener = new View.OnClickListener() {
		  public void onClick(View v) {
			  Intent i = new Intent(MenuActivity.this, InstructionsActivity.class);
			  startActivity(i);
		  }
	};

	protected void onActivityResult(int requestCode, int resultCode, Intent returnIntent) {

		  if (requestCode == LOGIN_REQUEST_ID) {
		     if(resultCode == RESULT_OK){      
		         int returned_score = returnIntent.getIntExtra("score", 0); 
		         if (returned_score > max_score){
		        	 max_score = returned_score;
		        	 highscore.setText("HighScore: " + returned_score); 
		         }
		         
		     }
		     if (resultCode == RESULT_CANCELED) {    
		         //Do Nothing
		     }
		}
	}
}
