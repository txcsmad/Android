package com.mad.tapcounter2;

import java.util.ArrayList;
import java.util.Set;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import com.parse.Parse;
import com.parse.ParseAnalytics;

public class MenuActivity extends Activity {

	private TextView title;
	private TextView highscore;
	private Button new_game;
	private Button instructions;
	public int high_score;
	private ListView highScoreListView;
	private ArrayList<Score> highScoreList;
	private CustomHighScoreListAdapter adapter;
	
	
	private SharedPreferences mPrefs;
	
	
	public int LOGIN_REQUEST_ID = 1234;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_menu);
		
		Parse.initialize(this, "4SpW1uswv332uukCdbvglVShlyrm6MxvMu9Uvfcx", "vvK9mFRrPVgJ2T2imIwoXksHZ1U8iHuQa0e4SzE4");

		Typeface title_face = Typeface.createFromAsset(getAssets(),"fonts/Roboto/Roboto-Regular.ttf");
//		mPrefs = getSharedPreferences("ttt_prefs", MODE_PRIVATE);
		
		highscore = (TextView) findViewById(R.id.highscore);
		new_game = (Button) findViewById(R.id.new_game);
		instructions = (Button) findViewById(R.id.instructions);
		title = (TextView) findViewById(R.id.title);
		highScoreListView = (ListView) findViewById(R.id.listview);
		setupListView();
		
		title.setTypeface(title_face);
//		max_score = mPrefs.getInt("highscore", 0);
//		highscore.setText("Highscore: " + max_score);
		
		new_game.setOnClickListener(newGameListener);
		instructions.setOnClickListener(instructionsListener);
	}
	
	@Override
	protected void onStop() {
		super.onStop();

		// Save the current high score
		SharedPreferences mPrefs = getSharedPreferences("ttt_prefs", MODE_PRIVATE);  
		SharedPreferences.Editor ed = mPrefs.edit();
		ed.putInt("highscore", high_score);
		ed.apply();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.menu, menu);
		return true;
	}
	
	View.OnClickListener newGameListener = new View.OnClickListener() {
		  public void onClick(View v) {
			  
			  Intent startIntent = new Intent(MenuActivity.this, GameActivity.class);
			  startIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
			  startActivityForResult(startIntent,LOGIN_REQUEST_ID);
			  overridePendingTransition(R.anim.top_down, 0);
		      
		  }
	};
	
	View.OnClickListener instructionsListener = new View.OnClickListener() {
		  public void onClick(View v) {
			  Intent i = new Intent(MenuActivity.this, HighScoreActivity.class);
			  startActivity(i);
		  }
	};

	protected void onActivityResult(int requestCode, int resultCode, Intent returnIntent) {

		  if (requestCode == LOGIN_REQUEST_ID) {
		     if(resultCode == RESULT_OK){
		         int returned_score = returnIntent.getIntExtra("score", 0); 
		         String name = returnIntent.getStringExtra("name");
		         Score new_score_item = new Score(name, returned_score);
//		         highScoreList.add(new_score_item);
		         sortedInsert(highScoreList, new_score_item);

		         high_score = returned_score;
		         adapter.notifyDataSetChanged();
		         
		         
		     }
		     if (resultCode == RESULT_CANCELED) {    
		         //Do Nothing
		     }
		}
	}
	
	private void sortedInsert(ArrayList<Score> arr, Score item){
		if(arr.size() == 0){
			arr.add(item);
		}
		else if (arr.size() < 5){
			for (int i = 0; i < arr.size(); i++){
				if (item.getScoreInt() > arr.get(i).getScoreInt()){
					arr.add(i,item);
					break;
				}
			}
		}
	}
	
	private void setupListView(){
        highScoreList = new ArrayList<Score>();
        
        adapter = new CustomHighScoreListAdapter(MenuActivity.this,
                R.layout.highscore_item,highScoreList);
        highScoreListView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

}
