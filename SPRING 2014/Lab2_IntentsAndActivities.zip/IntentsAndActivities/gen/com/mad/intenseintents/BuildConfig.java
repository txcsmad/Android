/** Automatically generated file. DO NOT MODIFY */
package com.mad.intenseintents;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}