package com.mad.intenseintents;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.TextView;

public class FirstActivity extends Activity {
	private TextView title;
	public int LOGIN_REQUEST_ID = 1234;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_first);
		
		title = (TextView) findViewById(R.id.signin_text);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.first, menu);
		return true;
	}

	public void openLogin(View v){
		Intent startIntent = new Intent(this, SecondActivity.class);
		startActivityForResult(startIntent,LOGIN_REQUEST_ID);
	}
	
	
	protected void onActivityResult(int requestCode, int resultCode, Intent returnIntent) {

		  if (requestCode == LOGIN_REQUEST_ID) {
		     if(resultCode == RESULT_OK){      
		         String result = returnIntent.getStringExtra("result_key"); 
		         title.setText("Hi, " + result);
		     }
		     if (resultCode == RESULT_CANCELED) {    
		         //Do Nothing
		     }
		  }
		}
}
