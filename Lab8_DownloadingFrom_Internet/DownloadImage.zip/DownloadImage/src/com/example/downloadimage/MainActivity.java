package com.example.downloadimage;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	public void download(View view) {
		Toast.makeText(this, "Download", Toast.LENGTH_SHORT).show();
		DownloadSomeImage downloadImage = new DownloadSomeImage();
		downloadImage.execute(new String[] { "http://icons.iconarchive.com/icons/google/chrome/256/Google-Chrome-Chromium-icon.png"});
	}
	
	
	private class DownloadSomeImage extends AsyncTask<String, Void, Bitmap> {

		private InputStream getHttpConnection(String urlString) throws IOException {
			InputStream stream = null;
			URL url = new URL(urlString);
			URLConnection urlConnection = url.openConnection();
			try {
				HttpURLConnection httpConnection = (HttpURLConnection) urlConnection;
				httpConnection.setRequestMethod("GET");
				httpConnection.connect();
				
				if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
					stream = httpConnection.getInputStream();
				}
				
			} catch(Exception e) {
				e.printStackTrace();
			}
			
			return stream;
		}
		
		private Bitmap downloadImage(String urlString) throws IOException {
			InputStream imgUrl = getHttpConnection(urlString);
			Bitmap bitmap = null;
			BitmapFactory.Options bmOptions = new BitmapFactory.Options();
			bmOptions.inSampleSize = 1;
			
			bitmap = BitmapFactory.decodeStream(imgUrl, null, bmOptions);
			imgUrl.close();
			return bitmap;
			
		}
		
		
		@Override
		protected Bitmap doInBackground(String... params) {
			// TODO Auto-generated method stub
			Bitmap bitmap = null;
			for (String item: params) {
				try {
					bitmap = downloadImage(item);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			return bitmap;
		}
		
		@Override
		protected void onPostExecute(Bitmap result) {
			ImageView image = (ImageView) findViewById(R.id.imageDownload);
			image.setImageBitmap(result);
			Toast.makeText(getApplicationContext(), "Downloaded", Toast.LENGTH_SHORT).show();
		}
		
	}
	

}
