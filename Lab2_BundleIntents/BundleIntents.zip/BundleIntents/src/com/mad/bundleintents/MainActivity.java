package com.mad.bundleintents;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends Activity {

	public static final String EXTRA_MESSAGE = "message";

	private EditText enterMessage;
	private Button submitMessage;
	private ListView listView;
	
	ListAdapter adapter;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		enterMessage = (EditText) findViewById(R.id.enterMessage);
		submitMessage = (Button) findViewById(R.id.submitMessage);
		listView = (ListView) findViewById(R.id.listView);
		
		String[] values = {"Carrera", "Cayman", "Vantage", "M3"};
		ArrayList<String> listValues = new ArrayList<String>();
		for (int i = 0; i < values.length; i++) {
			listValues.add(values[i]);
		}
		
		adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, listValues);
		listView.setAdapter(adapter);
		
		listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position,
					long id) {
				// TODO Auto-generated method stub
				String message = parent.getItemAtPosition(position).toString();
				//Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
				Intent intent = new Intent(getApplicationContext(), DisplayMessageActivity.class);
				intent.putExtra(EXTRA_MESSAGE, message);
				startActivity(intent);
			}
			
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	public void sendMessage(View view) {
		String message = enterMessage.getText().toString();
		if (message.equals("")) {
			message = "Empty String";
		}
		Bundle b = new Bundle();
		b.putString(EXTRA_MESSAGE, message);
		Intent intent = new Intent(this, DisplayMessageActivity.class);
		intent.putExtras(b);
		//intent.putExtra(EXTRA_MESSAGE, message);
		startActivity(intent);
	}

}
