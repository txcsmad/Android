/** Automatically generated file. DO NOT MODIFY */
package com.mad.lab5_madreview_menus;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}