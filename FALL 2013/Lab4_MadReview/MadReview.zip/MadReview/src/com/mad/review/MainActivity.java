package com.mad.review;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

	private EditText hourlyRate;
	private EditText hoursPerWeek;
	private Button calculate;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		hourlyRate = (EditText) findViewById(R.id.hourlyRate);
		hoursPerWeek = (EditText) findViewById(R.id.hoursPerWeek);
		calculate = (Button) findViewById(R.id.calculate);
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	public void calculate(View view) {
		double _hourlyRate = Double.parseDouble(hourlyRate.getText().toString());
		double _hoursPerWeek = Double.parseDouble(hoursPerWeek.getText().toString());
		double salary = _hourlyRate * _hoursPerWeek * 52;
		Toast.makeText(this, "You make " + salary + " per year!", Toast.LENGTH_LONG).show();
	}

}
