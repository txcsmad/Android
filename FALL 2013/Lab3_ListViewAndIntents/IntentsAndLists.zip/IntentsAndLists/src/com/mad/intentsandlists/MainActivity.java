package com.mad.intentsandlists;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends Activity {

	private Button newItem;
	private ListView listView;
	
	public ArrayList<String> listItems;
	
	private ArrayAdapter adapter;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		newItem = (Button) findViewById(R.id.newItem);
		listView = (ListView) findViewById(R.id.listView);
		
		listItems = new ArrayList<String>();
		listItems.add("Porsche");
		
		adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, listItems);
		listView.setAdapter(adapter);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	public void newItem(View view) {
		Toast.makeText(this, "Hey guys", Toast.LENGTH_LONG).show();
		Intent intent = new Intent(this, CreateNewItem.class);
		startActivityForResult(intent, 1);
		//startActivity(intent);
	}
	
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (data != null) {
			String message = data.getStringExtra("item");
			if (message.equals("")) {
				message = "Default String";
			}
			listItems.add(message);
			adapter.notifyDataSetChanged();
			Toast.makeText(this, message, Toast.LENGTH_LONG).show();
		}
	}

}
