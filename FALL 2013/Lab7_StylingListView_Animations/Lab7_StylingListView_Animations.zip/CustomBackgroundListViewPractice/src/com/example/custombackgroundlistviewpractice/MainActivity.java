package com.example.custombackgroundlistviewpractice;

import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.widget.ListView;

public class MainActivity extends Activity {
	
	private ListView listView;
	
	private ArrayList<String> listViewItems;
	CustomListViewAdapter adapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		listViewItems = new ArrayList<String>();
		
		listView = (ListView) findViewById(R.id.listView);
		
		for (int i = 0; i < 60; i++) {
			listViewItems.add("Test");	
		}
		
		adapter = new CustomListViewAdapter(this, R.layout.custom_listview_row, listViewItems);
		listView.setAdapter(adapter);
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
