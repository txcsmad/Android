package com.example.custombackgroundlistviewpractice;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class CustomListViewAdapter extends ArrayAdapter<String> {

	Context mContext;
	int textViewResourceId;
	ArrayList<String> data;
	
	public CustomListViewAdapter(Context context, int textViewResourceId, ArrayList<String> objects) {
		super(context, textViewResourceId, objects);
		// TODO Auto-generated constructor stub
		
		this.mContext = context;
		this.textViewResourceId = textViewResourceId;
		this.data = objects;
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		if (convertView == null) {
			LayoutInflater inflator = ((Activity) mContext).getLayoutInflater();
			convertView = inflator.inflate(textViewResourceId, parent, false);
		}
		
		String item = data.get(position);
		TextView textView = (TextView) convertView.findViewById(R.id.listItemText);
		textView.setText(item);
		textView.setTag(position);
		
		Animation animation = null;
		animation = AnimationUtils.loadAnimation(mContext, R.anim.push_up);
		animation.reset();
		animation.setDuration(500);
		convertView.startAnimation(animation);
		
		return convertView;
	}
	
}